<?php
session_start();
include "../../config.php";

$uname = $_POST['uname'];
$pass = $_POST['psw'];

$sql = "select * from cors_user where username = '$uname' and password = '$pass'";  
$result = mysqli_query($conn, $sql);  
if (mysqli_num_rows($result) === 1) {
    $row = mysqli_fetch_assoc($result);
    if ($row['username'] === $uname && $row['password'] === $pass) {
        header("Location: challenge1.php");
        $_SESSION['username'] = $row['username'];  
        exit();
    }
    else
    {
        header("Location: login.php?error=Incorect User name or password");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <link rel="stylesheet" href="login.css">
    <title>Login</title>
</head>
<body>
    <h2>CORS Lab 1</h2>
    <br>
    <h2>Login</h2><br>
    <form action='#' method="POST">
        <div class="container">
            <label for="uname">Username</label><br>
            <input type="text" placeholder="Enter Username" name="uname" size="40"><br>
    
            <label for="psw">Password</label><br>
            <input type="password" placeholder="Enter Password" name="psw" size="40"><br><br>
        
            <button type="submit" class="btn btn-primary">Submit</button>
            <br>
            <br>
            </div>
            
        </div>
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js" integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/" crossorigin="anonymous"></script>

</body>
</html>
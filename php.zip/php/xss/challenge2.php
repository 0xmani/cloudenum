<?php

include "../config.php";

if (isset($_POST['submit'])){

    $name = $_POST['name'];
    $comment = $_POST['comment'];

    $sql = "INSERT INTO comments VALUES ('$name','$comment')";

    $result = mysqli_query($conn, $sql);

    if($result){
        header("Location: challenge2.php");
    }
    else{
        echo "Failed: " .mysqli_error($conn);
    }
}


?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="index.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
	<title>XSS Challenge 2</title>
</head>
<body>

<style>
.heading1{
  text-align: center;
  padding: 50px;
}

.form-group{
    text-align: center;
}

.comment {
    width: 40%;
    height: 100px;
    padding: 10px;
}

.myname {
    width: 40%;
    height: 50px;
    padding: 10px;
}

.com{
    padding-top: 60px;
    padding-left: 60px;
}

.ttag{
    padding-top: 40px;
    padding-left: 60px;
    font-size: 20px;
}

</style>

<h2 class="heading1">
Stored XSS Challenge
</h2>

<form class="input" method="POST">
  <div class="form-group">
    <input class="myname" type="text" name="name" placeholder="Enter your Name" size="30"><br><br>
    <textarea class="comment" type="text" name="comment">Comments</textarea><br><br>
    <button type="submit" name="submit" class="btn btn-primary">Submit</button>
  </div>
</form>
<br>

<h4 class="com">Comments:</h4>

<div class="ttag">
<?php
include "../config.php";
$sql = "SELECT * FROM `comments`";
$result = mysqli_query($conn, $sql);
while ($row = mysqli_fetch_assoc($result)){
    ?>
    <tr>
        <th><b>Name: </b> <?php echo $row['name'];?></th><br>
        <th><b>Comment: </b> <?php echo $row['comment']; ?></th><br><br><br>
    </tr>

    <?php
}
?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ"
        crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"
        integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN"
        crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js"
        integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/"
        crossorigin="anonymous"></script>

</body>
</html>
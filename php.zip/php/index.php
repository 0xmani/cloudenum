<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01"
            aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
        </button>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
            <a class="navbar-brand" href="#"><img src="Aqoon.png" width="100px"></a>
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                <li class="nav-item active">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="labs.php">Labs</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">My account</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Logout</a>
                </li>
                <br><br>
            </ul>
        </div>
    </nav>
</head>

<style>
    
.card-group{
    padding-top: 80px;
    padding-left: 80px;
    padding-right: 80px;
}

.card-img-top{
    width: 250px;
    padding-left: 100px;
}

.card-body{
    width: 300px;
}

</style>

<body>


<div class="card-group">
  <div class="card">
    <img class="card-img-top" src="boost.png" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Boost your Career</h5>
      <p class="card-text">The Web Security Academy is a strong step toward a career in cybersecurity.</p>
    </div>
    <div class="card-footer">
      <small class="text-muted">Last updated 5 days ago</small>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="flexibility.png" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Flexible learning</h5>
      <p class="card-text">Learn anywhere, anytime, with free interactive labs and progress-tracking.</p>
    </div>
    <div class="card-footer">
      <small class="text-muted">Last updated 5 days ago</small>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="expert.png" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Learn from experts</h5>
      <p class="card-text">This provides insights into the nature of thinking and problem solving skills.</p>
    </div>
    <div class="card-footer">
      <small class="text-muted">Last updated 5 days ago</small>
    </div>
  </div>
</div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"
        integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js"
        integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/"
        crossorigin="anonymous"></script>
        <!-- Footer -->
<footer class="page-footer font-small blue">

    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2022 Copyright:
      <a href="#">Aqoon Institute</a>
    </div>
    <!-- Copyright -->
  
  </footer>
  <!-- Footer -->
</body>

</html>
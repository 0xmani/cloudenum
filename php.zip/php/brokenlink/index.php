<!DOCTYPE html>
<html>
<head>
<title>Broken Link Hijacking</title>

<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="index.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

</div>

</head>

<body>

<div class="heading">
  <h2>Broken Link Hijacking</h2>
  <p>Broken Link Hijacking is a type of cyber attack that exploits the use of expired or invalid external links embedded on your website. If your web application or website makes use of third party services or resources loaded from an external url or redirects to these services and they happen to not be available anymore or invalid (usually happens due to expired domains that are hijacked), hackers can exploit these vulnerable links to launch various types of cyber attacks like Cross Site Scripting, used to steal data and impersonation.</p>
  <h4>Objective</h4>
  <p>There is a Vulnerability in this page, exploit the vulnerability and take a screenshot and send it to Lab Moderator.</p>
</div>

<div class="broken">
  
  <h4>Follow us on:</h4>
  <div class="insta"><a href="#"><img src="../images/insta.png" width="80px"></div>
  <div class="twitter"><a href="#"><img src="../images/twitter.png" width="80px"></div>

</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ"
        crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"
        integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN"
        crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js"
        integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/"
        crossorigin="anonymous"></script>

</body>


</html>
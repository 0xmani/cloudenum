<html>
<head>
<title>File Upload Challeges</title>

<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="index.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

</div>

</head>

<body>

<div class="heading">
  <h2>File Upload Vulnerabilities</h2>
  <p>File upload vulnerabilities are when a web server allows users to upload files to its filesystem without sufficiently validating things like their name, type, contents, or size. Failing to properly enforce restrictions on these could mean that even a basic image upload function can be used to upload arbitrary and potentially dangerous files instead. This could even include server-side script files that enable remote code execution.
</p>
  <h4>Objective</h4>
  <p>There are 3 Vulnerable File upload labs are provided below, exploit the vulnerabilities and take a screenshot and send it to Lab Moderator<br>
  </b></p>
</div>

<div class="section1">
  <section>
    <h5>File Upload Challenge 1</h5>
    <p>SSRF through GET Method</p>
    <a href="challenge1.php" class="btn btn-primary">File Upload Lab 1</a>
  </section>
</div>

<div class="section2">
  <section>
    <h5>File Upload Challenge 2</h5>
    <p>SSRF through POST Method</p>
    <a href="challenge2.php" class="btn btn-primary">File Upload Lab 2</a>
  </section>
</div>

<div class="section2">
  <section>
    <h5>File Upload Challenge 3</h5>
    <p>SSRF through GET Method (Image Render)</p>
    <a href="challenge3.php" class="btn btn-primary">File Upload Lab 3</a>
  </section>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ"
        crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"
        integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN"
        crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js"
        integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/"
        crossorigin="anonymous"></script>

</body>


</html>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01"
            aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
        </button>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
            <a class="navbar-brand" href="#"><img src="Aqoon.png" width="100px"></a>
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                <li class="nav-item active">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="labs.php">Labs</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">My account</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Logout</a>
                </li>
                <br><br>
            </ul>
        </div>
    </nav>
</head>

<style>
    
.hword{
    padding: 50px;
}


</style>

<body>

<br>

<div class="hword">
<h3>Access Lab:</h3><br>

<div class="card w-75">
  <div class="card-body">
    <h5 class="card-title">HTML Injection</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="xss/index.php" class="btn btn-primary">Access Lab</a>
  </div>
</div>

<div class="card w-75">
  <div class="card-body">
    <h5 class="card-title">Cross Site Scripting (XSS)</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="xss/index.php" class="btn btn-primary">Access Lab</a>
  </div>
</div>

<div class="card w-75">
  <div class="card-body">
    <h5 class="card-title">SQL Injection</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="sqli/index.php" class="btn btn-primary">Access Lab</a>
  </div>
</div>

<div class="card w-75">
  <div class="card-body">
    <h5 class="card-title">Server Side Request Forgery</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="ssrf/index.php" class="btn btn-primary">Access Lab</a>
  </div>
</div>

<div class="card w-75">
  <div class="card-body">
    <h5 class="card-title">Command Injection</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="cmdi/index.php" class="btn btn-primary">Access Lab</a>
  </div>
</div>

<div class="card w-75">
  <div class="card-body">
    <h5 class="card-title">Parameter Tampering</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="parametertampering/phpcart/index.php" class="btn btn-primary">Access Lab</a>
  </div>
</div>

<div class="card w-75">
  <div class="card-body">
    <h5 class="card-title">Authentication</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="#" class="btn btn-primary">Access Lab</a>
  </div>
</div>

<div class="card w-75">
  <div class="card-body">
    <h5 class="card-title">IDOR</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="#" class="btn btn-primary">Access Lab</a>
  </div>
</div>

<div class="card w-75">
  <div class="card-body">
    <h5 class="card-title">File Inclusion</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="fileinclusion/index.php" class="btn btn-primary">Access Lab</a>
  </div>
</div>

<div class="card w-75">
  <div class="card-body">
    <h5 class="card-title">Cross Site Request Forgery (CSRF)</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="csrf/" class="btn btn-primary">Access Lab</a>
  </div>
</div>

<div class="card w-75">
  <div class="card-body">
    <h5 class="card-title">Open Redirect</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="openredirect/index.php" class="btn btn-primary">Access Lab</a>
  </div>
</div>

<div class="card w-75">
  <div class="card-body">
    <h5 class="card-title">Broken Link Hijacking</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="brokenlink/index.php" class="btn btn-primary">Access Lab</a>
  </div>
</div>

<div class="card w-75">
  <div class="card-body">
    <h5 class="card-title">CORS - Cross Origin Resource Sharing</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="cors/index.php" class="btn btn-primary">Access Lab</a>
  </div>
</div>
</div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"
        integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js"
        integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/"
        crossorigin="anonymous"></script>
        <!-- Footer -->
<footer class="page-footer font-small blue">

    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2022 Copyright:
      <a href="#">Aqoon Institute</a>
    </div>
    <!-- Copyright -->
  
  </footer>
  <!-- Footer -->
</body>

</html>
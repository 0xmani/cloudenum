<?php
session_start();
if ($_SESSION['username'] == True) {  
	echo "";
}
else{
	header("Location: login.php");
}

?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Home</title>
</head>
<body>
<h2> Congrats! Solved SQLi Lab 1</h2>
</body>
</html>
<?php

session_start();
include "../../config.php";

$host = 'localhost';
$username = 'labuser';
$password = 'password';
$dbname = 'lab';

$mysqli = new mysqli("$host", "$username", "$password", "$dbname");

if (mysqli_connect_errno()){
    echo "Failed to connect to Mysql: (" .$mysqli->connect_errno . ") " . $mysqli->connect_error;
    exit();
}else{
    
    $uname = $_POST["uname"];
    $pass = $_POST["psw"];
    $sql = "select * from sqli_users where username = '$uname' and password = '$pass'";
    $res=$conn->query($sql);
    if(!$res)
    {
        echo("Error Description: " .$conn->error);
        exit();
    }
    while($row=$res->fetch_assoc()){
        header("Location: home.php");
        $_SESSION['username'] = $row['username'];
        exit();
        //echo 'id: '.$row['id'];
        //print("\n");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <link rel="stylesheet" href="login.css">
    <title>Login</title>
</head>
<body>
    <h2>SQLi Lab 1</h2>
    <br>
    <h2>Login</h2><br>
    <form action='#' method="POST">
        <div class="container">
            <label for="uname">Username</label><br>
            <input type="text" placeholder="Enter Username" name="uname" size="40"><br>
    
            <label for="psw">Password</label><br>
            <input type="password" placeholder="Enter Password" name="psw" size="40"><br><br>
        
            <button type="submit" class="btn btn-primary">Submit</button>
            <br>
            <br>
            </div>
            
        </div>
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js" integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/" crossorigin="anonymous"></script>

</body>
</html>